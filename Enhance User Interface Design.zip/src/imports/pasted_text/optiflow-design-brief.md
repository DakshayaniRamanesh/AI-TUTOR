# Figma Design Generation Prompt — AI Tutor Video Platform

Copy everything below into Figma's AI design tool (First Draft) or use it as a creative brief for a designer.

---

## The prompt

Design a premium, visually distinctive web/desktop application for an AI-powered tutoring platform that turns a student's PDF (textbook chapter, lecture notes, past paper) into a narrated, animated explainer video generated with mathematical animation software, similar in visual language to 3Blue1Brown-style videos. The product is called OptiFlow Tutor. This is not a generic SaaS dashboard — avoid the typical "purple gradient AI startup" look entirely. The audience is students studying technical subjects (math, physics, engineering, CS), so the design should feel precise, calm, and confidence-inspiring — like a well-designed scientific instrument, not a flashy consumer app.

### Visual identity direction

Take design cues from: academic typesetting (think Knuth's TeX aesthetic, university course sites redone well), scientific instrument panels (oscilloscopes, lab equipment — clean dark bezels, precise readouts), and the aesthetic of the animation content itself (mathematical diagrams, coordinate grids, vector fields, clean geometric forms). Avoid: generic rounded-everything SaaS UI, purple-to-pink gradients, stock illustration people, emoji, cartoonish mascots.

**Color system:** A dark-mode-first "ink and chalkboard" palette — deep charcoal/near-black background (not pure black), with a warm off-white for primary text (like chalk or paper, not stark white). One confident accent color used sparingly and consistently — a warm amber or a deep teal — reserved only for active states, the currently-playing timestamp marker, and primary CTAs. A secondary muted blue for informational states (agent-thinking indicators, links). Avoid rainbow color-coding; let typography hierarchy and spacing do most of the work, color should feel earned, not decorative.

**Typography:** Pair a technical/geometric sans-serif for UI chrome (navigation, buttons, labels) with a serif or slab serif for headings and any explanatory prose — this creates the "academic instrument" feel and differentiates it instantly from typical product UI which is all-sans. Set body text generously — 16-18px minimum, comfortable line height (1.6-1.7) — since this is a reading- and watching-heavy product. Any math notation in the UI (not just inside videos) should look properly typeset, not like plain text with slashes.

**Texture and depth:** Flat design with restrained use of hairline borders (1px, low-opacity) rather than heavy drop shadows or card elevation. Where depth is needed, use very subtle background value shifts rather than shadows. Grid lines and coordinate-axis motifs can appear as extremely subtle background texture in empty states — a nod to the math content — without being distracting.

### Screens and components to design

**1. Upload / new lesson screen**
Not a boring drag-and-drop box. Design this as the entry point that sets the tone for the whole product. Include: a large, calm PDF drop zone with a subtle animated coordinate-grid background; a text field for the student's specific question or focus area; a "difficulty" control styled like a precision dial or slider rather than a generic toggle (options like "foundational," "standard," "rigorous"); recent/past lessons shown as a horizontal shelf of thumbnail cards below, each thumbnail showing a still frame from the generated video plus the source PDF's title.

**2. Live generation / agent status screen**
This is a key differentiation opportunity — do not design a generic spinner or progress bar. Design a vertical or horizontal pipeline visualization showing each agent stage as it activates in sequence: reading the document, planning the lesson, writing the narration, generating the animation code, rendering. Each stage should have its own small live indicator (pulse, subtle motion, or a live counter like "developed 340 words" for the planning stage) so the student watching feels like something intelligent is actively happening, not just waiting. Include an estimated time remaining and an option to be notified when ready instead of waiting on the screen.

**3. Main video player / lesson screen — the centerpiece**
This is the most important screen. Design a split-view layout:
- Left or top: the video player itself, styled with minimal chrome — thin custom scrubber (not a default browser control), chapter markers along the timeline labeled with concept names (not just timestamps), and small colored dots on the timeline representing places where other students have asked annotation questions (a "heatmap of confusion" — denser clusters of dots where more students paused).
- Right or bottom: a synced PDF viewer showing the source document, with the currently-relevant paragraph highlighted and auto-scrolling in sync with the video's narration.
- A floating, minimal annotation tool: a pencil/highlighter cursor mode that lets the student draw directly on the paused video frame and type a question, styled like an actual whiteboard marker interaction, not a generic comment box.
- Below the player: an auto-generating glossary rail that fills in with terms as the student encounters and asks about them during the session, each shown as a small flippable card (term on front, definition + jump-to-timestamp on back).

**4. Annotation response view**
When a student asks a question via drawing, design the moment where a new short answer clip is generated and inserted — this should feel like a seamless "the tutor leans in and explains this specific thing," not a jarring popup. Consider a picture-in-picture style inset that expands from the exact point the student drew on, plays the explanation, then collapses back into the timeline as a new permanent marker.

**5. Personal dashboard**
A student's home base: a grid of past lessons (thumbnail + source PDF name + subject tag + completion status), a running personal glossary/flashcard collection pulled from all their annotation questions across every lesson, and a lightweight spaced-repetition prompt card ("You asked about eigenvalues 3 days ago — quick recap?"). Style subject tags as small precise labels (physics, calculus, etc.) using the muted informational blue, not loud category colors.

**6. Shared classroom view (if relevant)**
A teacher-facing or class-facing variant showing one shared lesson with a combined annotation timeline from every student in the class, so one student's clarifying clip benefits everyone. Visually distinguish "my questions" from "class questions" on the timeline using subtle marker shape difference (not just color, for accessibility).

### Interaction and motion notes for the designer/prototype

Micro-interactions should feel precise and mechanical rather than bouncy or playful — think the satisfying click of a well-made dial, not a springy cartoon bounce. Timeline markers should have a subtle hover state showing a text preview of the question asked at that point. The agent-status pipeline stages should animate with a steady left-to-right or top-to-bottom fill rather than an indeterminate spinner, since the underlying process is genuinely sequential and showing that builds trust.

### What to explicitly avoid

No stock "AI robot" or brain iconography. No purple/pink gradient backgrounds. No generic rounded card grids with heavy drop shadows. No emoji anywhere in the UI. No cartoon mascot. No default browser video player chrome. The overall feeling should be "a serious, beautifully designed scientific tool a top student would be proud to use," not "another AI wrapper app."

### Deliverables requested

Please generate: a landing/marketing-adjacent hero treatment for the upload screen, the live-generation agent-status screen, the main split-view video + PDF player screen with annotation tool visible, and the personal dashboard — as a connected flow, using one consistent design system (color tokens, type scale, spacing scale, component library for buttons/cards/markers) applied across all four screens.

---

## Tips for using this in Figma

- If using Figma's First Draft / AI generation, paste the whole prompt as one block — it handles long, detailed prompts better than short ones.
- Generate one screen at a time if the tool struggles with all four at once; use the same opening paragraph (visual identity direction) on each generation to keep them visually consistent.
- After generation, manually extract the color tokens, type scale, and spacing values it lands on into a proper Figma variables/styles library before designing further screens, so everything after screen 1 stays consistent rather than drifting.