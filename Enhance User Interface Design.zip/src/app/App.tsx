import { useState } from 'react'
import { AnimatePresence, motion } from 'motion/react'
import { NavBar, type Screen } from './components/NavBar'
import { UploadScreen } from './components/UploadScreen'
import { GenerationScreen } from './components/GenerationScreen'
import { PlayerScreen } from './components/PlayerScreen'
import { DashboardScreen } from './components/DashboardScreen'

export default function App() {
  const [screen, setScreen] = useState<Screen>('dashboard')

  const nav = (s: Screen) => setScreen(s)

  return (
    <div
      className="dark"
      style={{
        minHeight: '100vh',
        background: '#18181a',
        color: '#f0ead6',
        fontFamily: "'IBM Plex Sans', system-ui, sans-serif",
      }}
    >
      <NavBar screen={screen} onNavigate={nav} />

      <AnimatePresence mode="wait">
        <motion.div
          key={screen}
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -4 }}
          transition={{ duration: 0.18, ease: 'easeInOut' }}
          style={{ minHeight: 'calc(100vh - 52px)' }}
        >
          {screen === 'dashboard' && (
            <DashboardScreen
              onOpenLesson={() => nav('player')}
              onNewLesson={() => nav('upload')}
            />
          )}
          {screen === 'upload' && (
            <UploadScreen
              onGenerate={() => nav('generating')}
              onOpenLesson={() => nav('player')}
            />
          )}
          {screen === 'generating' && (
            <GenerationScreen
              onComplete={() => nav('player')}
              onBack={() => nav('upload')}
            />
          )}
          {screen === 'player' && (
            <PlayerScreen onBack={() => nav('dashboard')} />
          )}
        </motion.div>
      </AnimatePresence>
    </div>
  )
}
