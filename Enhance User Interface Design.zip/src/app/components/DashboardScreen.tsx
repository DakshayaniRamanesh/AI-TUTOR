import { useState } from 'react'
import { motion } from 'motion/react'
import { Plus, Clock, BookOpen, RotateCw, TrendingUp, Layers, Zap } from 'lucide-react'

interface DashboardScreenProps {
  onOpenLesson: () => void
  onNewLesson: () => void
}

const A = '#d4a84b'
const B = '#5b87c5'
const T = '#4a9e8e'
const S1 = '#1e1e22'
const S2 = '#222228'
const S3 = '#28282e'
const BR = 'rgba(240,234,214,0.08)'
const BRS = 'rgba(240,234,214,0.13)'
const C1 = '#f0ead6'
const C2 = '#9c9a8e'
const C3 = '#6b6960'
const FF = "'IBM Plex Sans', system-ui, sans-serif"

const LESSONS = [
  { id: 1, title: 'Eigenvalues & Eigenvectors', source: 'Linear Algebra — Ch. 5', subject: 'Mathematics', subjectColor: A, duration: '15:34', progress: 57, shape: 'eigen', date: 'Today' },
  { id: 2, title: 'Fourier Transforms',         source: 'Signals & Systems — Ch. 4', subject: 'Engineering', subjectColor: B, duration: '18:42', progress: 72, shape: 'wave', date: '3 days ago' },
  { id: 3, title: 'Differential Equations',     source: 'Calculus III — Lecture 9', subject: 'Mathematics', subjectColor: A, duration: '24:15', progress: 100, shape: 'field', date: '1 week ago' },
  { id: 4, title: 'Quantum States',             source: 'Intro Quantum Mechanics', subject: 'Physics', subjectColor: T, duration: '31:07', progress: 45, shape: 'wave2', date: '2 weeks ago' },
  { id: 5, title: 'Gradient Descent',           source: 'ML Fundamentals — Ch. 5', subject: 'CS / ML', subjectColor: '#c87941', duration: '22:54', progress: 100, shape: 'contour', date: '3 weeks ago' },
  { id: 6, title: 'Stokes\' Theorem',           source: 'Vector Calculus — Ch. 7', subject: 'Mathematics', subjectColor: A, duration: '20:11', progress: 0, shape: 'stokes', date: '1 month ago' },
]

const FLASHCARDS = [
  { term: 'Eigenvalue', lesson: 'Eigenvalues & Eigenvectors', daysAgo: 0 },
  { term: 'Fourier Series', lesson: 'Fourier Transforms', daysAgo: 3 },
  { term: 'Hilbert Space', lesson: 'Quantum States', daysAgo: 14 },
  { term: 'Gradient', lesson: 'Gradient Descent', daysAgo: 21 },
  { term: 'Phase Space', lesson: 'Differential Equations', daysAgo: 7 },
]

const SR_CARD = { term: 'eigenvalues', lesson: 'Eigenvalues & Eigenvectors', daysAgo: 3 }

function ThumbnailSVG({ shape, progress }: { shape: string; progress: number }) {
  return (
    <div style={{ width: '100%', height: 100, background: '#0c0c0e', position: 'relative', overflow: 'hidden' }}>
      <svg style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }} viewBox="0 0 210 100">
        <defs>
          <pattern id={`dg-${shape}`} width="18" height="18" patternUnits="userSpaceOnUse">
            <path d="M18 0L0 0 0 18" fill="none" stroke="rgba(240,234,214,0.09)" strokeWidth="0.5" />
          </pattern>
        </defs>
        <rect width="210" height="100" fill={`url(#dg-${shape})`} />
        {shape === 'eigen' && (
          <>
            <line x1="105" y1="12" x2="105" y2="88" stroke="rgba(240,234,214,0.18)" strokeWidth="0.7" />
            <line x1="20" y1="50" x2="190" y2="50" stroke="rgba(240,234,214,0.18)" strokeWidth="0.7" />
            <line x1="105" y1="50" x2="150" y2="18" stroke={A} strokeWidth="1.8" />
            <polygon points="150,18 143,24 149,27" fill={A} />
            <line x1="105" y1="50" x2="64" y2="78" stroke={B} strokeWidth="1.3" strokeDasharray="4 3" />
          </>
        )}
        {shape === 'wave' && (
          <path d="M10,50 Q30,22 50,50 Q70,78 90,50 Q110,22 130,50 Q150,78 170,50 Q190,22 200,50" fill="none" stroke={A} strokeWidth="1.6" opacity="0.75" />
        )}
        {shape === 'field' && Array.from({ length: 5 }).map((_, i) =>
          Array.from({ length: 4 }).map((_, j) => (
            <line key={`${i}${j}`} x1={18 + i * 44} y1={18 + j * 22} x2={18 + i * 44 + 13} y2={18 + j * 22 - (i - 2) * 3.5} stroke="rgba(240,234,214,0.45)" strokeWidth="1" />
          ))
        )}
        {shape === 'wave2' && <path d="M8,62 Q38,14 68,46 Q98,78 128,32 Q158,4 180,42 Q196,64 202,54" fill="none" stroke={T} strokeWidth="1.6" opacity="0.7" />}
        {shape === 'contour' && [40, 28, 18, 10].map((r, i) => (
          <ellipse key={i} cx="105" cy="50" rx={r + 16} ry={r * 0.55 + 9} fill="none" stroke={i === 0 ? `rgba(212,168,75,0.55)` : 'rgba(240,234,214,0.13)'} strokeWidth="0.9" />
        ))}
        {shape === 'contour' && <circle cx="105" cy="50" r="3.5" fill={A} opacity="0.9" />}
        {shape === 'stokes' && (
          <>
            {[30, 50, 70, 90].map((x, i) => (
              <path key={i} d={`M${x},32 Q${x + 10},50 ${x},68`} fill="none" stroke="rgba(91,135,197,0.45)" strokeWidth="1" />
            ))}
            <path d="M22,50 Q55,20 105,50 Q155,80 188,50" fill="none" stroke={T} strokeWidth="1.5" strokeDasharray="4 3" />
          </>
        )}
      </svg>
      {/* Progress bar */}
      {progress > 0 && progress < 100 && (
        <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, height: 2, background: 'rgba(240,234,214,0.07)' }}>
          <div style={{ height: '100%', width: `${progress}%`, background: A }} />
        </div>
      )}
      {progress === 100 && (
        <div style={{ position: 'absolute', top: 7, right: 7, fontSize: 9.5, padding: '2px 6px', borderRadius: 2, background: 'rgba(74,158,142,0.18)', border: '1px solid rgba(74,158,142,0.3)', color: T, letterSpacing: '0.06em' }}>DONE</div>
      )}
    </div>
  )
}

export function DashboardScreen({ onOpenLesson, onNewLesson }: DashboardScreenProps) {
  const [flippedCards, setFlippedCards] = useState<Set<number>>(new Set())
  const toggleFlip = (i: number) => setFlippedCards(p => { const n = new Set(p); n.has(i) ? n.delete(i) : n.add(i); return n })

  const totalHours = Math.round(LESSONS.reduce((s, l) => s + (parseInt(l.duration) + (parseInt(l.duration.split(':')[1]) / 60)), 0) * 10) / 10
  const completedCount = LESSONS.filter(l => l.progress === 100).length

  return (
    <div style={{ minHeight: 'calc(100vh - 52px)', background: '#18181a', display: 'flex', fontFamily: FF }}>
      {/* Sidebar */}
      <div style={{ width: 240, borderRight: `1px solid ${BR}`, background: '#111113', padding: '28px 0', flexShrink: 0, display: 'flex', flexDirection: 'column', gap: 0 }}>
        <div style={{ padding: '0 20px 24px', borderBottom: `1px solid ${BR}` }}>
          <div style={{ fontSize: 11, color: C3, letterSpacing: '0.08em', marginBottom: 14 }}>OVERVIEW</div>
          {[
            { label: 'Total lessons', value: LESSONS.length, icon: Layers },
            { label: 'Completed', value: completedCount, icon: TrendingUp },
            { label: 'Study time', value: `~${totalHours}h`, icon: Clock },
            { label: 'Terms learned', value: 24, icon: BookOpen },
          ].map(({ label, value, icon: Icon }) => (
            <div key={label} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 11 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 7 }}>
                <Icon size={13} color={C3} strokeWidth={1.5} />
                <span style={{ fontSize: 12.5, color: C2 }}>{label}</span>
              </div>
              <span style={{ fontSize: 13.5, fontWeight: 500, color: C1, fontFamily: "'IBM Plex Sans', monospace" }}>{value}</span>
            </div>
          ))}
        </div>

        {/* Spaced repetition card */}
        <div style={{ padding: '20px 20px', borderBottom: `1px solid ${BR}` }}>
          <div style={{ fontSize: 11, color: C3, letterSpacing: '0.08em', marginBottom: 12 }}>SPACED REPETITION</div>
          <div style={{ background: 'rgba(212,168,75,0.06)', border: '1px solid rgba(212,168,75,0.18)', borderRadius: 5, padding: '11px 12px' }}>
            <div style={{ display: 'flex', alignItems: 'flex-start', gap: 8, marginBottom: 10 }}>
              <Zap size={13} color={A} style={{ marginTop: 2, flexShrink: 0 }} />
              <p style={{ margin: 0, fontSize: 12, color: C2, lineHeight: 1.6 }}>
                You asked about{' '}
                <span style={{ color: A, fontWeight: 500 }}>{SR_CARD.term}</span>{' '}
                {SR_CARD.daysAgo} days ago — quick recap?
              </p>
            </div>
            <div style={{ fontSize: 10, color: C3, marginBottom: 8 }}>from: {SR_CARD.lesson}</div>
            <button onClick={onOpenLesson} style={{ width: '100%', padding: '7px', background: 'rgba(212,168,75,0.12)', border: '1px solid rgba(212,168,75,0.22)', borderRadius: 3, color: A, fontSize: 11.5, fontWeight: 500, cursor: 'pointer', fontFamily: FF }}>
              Review now
            </button>
          </div>
        </div>

        {/* Subject breakdown */}
        <div style={{ padding: '20px 20px' }}>
          <div style={{ fontSize: 11, color: C3, letterSpacing: '0.08em', marginBottom: 12 }}>SUBJECTS</div>
          {[
            { label: 'Mathematics', color: A, count: 3 },
            { label: 'Engineering', color: B, count: 1 },
            { label: 'Physics', color: T, count: 1 },
            { label: 'CS / ML', color: '#c87941', count: 1 },
          ].map(s => (
            <div key={s.label} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 9 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 7 }}>
                <div style={{ width: 6, height: 6, borderRadius: '50%', background: s.color, flexShrink: 0 }} />
                <span style={{ fontSize: 12, color: C2 }}>{s.label}</span>
              </div>
              <span style={{ fontSize: 11.5, color: C3, fontFamily: 'monospace' }}>{s.count}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Main content */}
      <div style={{ flex: 1, overflow: 'auto', padding: '28px 32px 60px' }}>
        {/* Header row */}
        <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: 28 }}>
          <div>
            <h1 style={{ margin: 0, fontFamily: "'IBM Plex Serif', Georgia, serif", fontSize: 26, fontWeight: 600, color: C1, lineHeight: 1.3 }}>
              Your Lessons
            </h1>
            <p style={{ margin: '5px 0 0', color: C2, fontSize: 14, lineHeight: 1.6 }}>
              {LESSONS.length} lessons · {completedCount} completed
            </p>
          </div>
          <motion.button whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }} onClick={onNewLesson} style={{
            display: 'flex', alignItems: 'center', gap: 7, padding: '9px 18px',
            background: A, border: 'none', borderRadius: 5, color: '#18181a',
            fontSize: 13, fontWeight: 600, cursor: 'pointer', fontFamily: FF,
          }}>
            <Plus size={14} strokeWidth={2.5} /> New Lesson
          </motion.button>
        </div>

        {/* Lessons grid */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(210px, 1fr))', gap: 14, marginBottom: 40 }}>
          {LESSONS.map(l => (
            <motion.div key={l.id} whileHover={{ y: -4 }} transition={{ duration: 0.15 }} onClick={onOpenLesson} style={{
              background: S1, border: `1px solid ${BR}`, borderRadius: 6, overflow: 'hidden', cursor: 'pointer',
            }}>
              <ThumbnailSVG shape={l.shape} progress={l.progress} />
              <div style={{ padding: '10px 13px 13px' }}>
                <div style={{ fontSize: 12.5, fontWeight: 500, color: C1, marginBottom: 3, lineHeight: 1.3 }}>{l.title}</div>
                <div style={{ fontSize: 11, color: C3, marginBottom: 9, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{l.source}</div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span style={{ fontSize: 10.5, padding: '2px 7px', borderRadius: 3, background: `${l.subjectColor}20`, color: l.subjectColor }}>{l.subject}</span>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <span style={{ fontSize: 10, color: C3 }}>{l.date}</span>
                    <span style={{ fontSize: 10.5, color: C3, display: 'flex', alignItems: 'center', gap: 3 }}>
                      <Clock size={10} />{l.duration}
                    </span>
                  </div>
                </div>
                {l.progress > 0 && l.progress < 100 && (
                  <div style={{ marginTop: 9, height: 2, background: 'rgba(240,234,214,0.07)', borderRadius: 1 }}>
                    <div style={{ height: '100%', width: `${l.progress}%`, background: A, borderRadius: 1 }} />
                  </div>
                )}
              </div>
            </motion.div>
          ))}
        </div>

        {/* Glossary / flashcards section */}
        <div>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 10, marginBottom: 16 }}>
            <h2 style={{ margin: 0, fontFamily: "'IBM Plex Serif', Georgia, serif", fontSize: 17, fontWeight: 600, color: C1 }}>Personal Glossary</h2>
            <span style={{ fontSize: 12, color: C3 }}>{FLASHCARDS.length} terms across all lessons</span>
          </div>
          <div style={{ display: 'flex', gap: 11, flexWrap: 'wrap' }}>
            {FLASHCARDS.map((fc, i) => {
              const flipped = flippedCards.has(i)
              return (
                <div key={fc.term} onClick={() => toggleFlip(i)} style={{ perspective: 900, width: 178, height: 105, cursor: 'pointer', flexShrink: 0 }}>
                  <motion.div animate={{ rotateY: flipped ? 180 : 0 }} transition={{ duration: 0.42, ease: [0.25, 0.46, 0.45, 0.94] }}
                    style={{ width: '100%', height: '100%', position: 'relative', transformStyle: 'preserve-3d' }}>
                    {/* Front */}
                    <div style={{ position: 'absolute', inset: 0, backfaceVisibility: 'hidden', background: S1, border: `1px solid ${BRS}`, borderRadius: 5, padding: '11px 13px', display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
                      <div style={{ fontSize: 13.5, fontFamily: "'IBM Plex Serif', Georgia, serif", fontWeight: 500, color: C1, lineHeight: 1.3 }}>{fc.term}</div>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <span style={{ fontSize: 10, color: C3, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', maxWidth: '75%' }}>{fc.lesson}</span>
                        <span style={{ fontSize: 9.5, color: fc.daysAgo === 0 ? T : fc.daysAgo <= 7 ? B : C3 }}>
                          {fc.daysAgo === 0 ? 'today' : `${fc.daysAgo}d ago`}
                        </span>
                      </div>
                    </div>
                    {/* Back */}
                    <div style={{ position: 'absolute', inset: 0, backfaceVisibility: 'hidden', transform: 'rotateY(180deg)', background: 'rgba(212,168,75,0.06)', border: '1px solid rgba(212,168,75,0.2)', borderRadius: 5, padding: '11px 13px', display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: 8 }}>
                      <div style={{ fontSize: 11.5, color: A, fontWeight: 500, fontFamily: "'IBM Plex Serif', serif" }}>{fc.term}</div>
                      <div style={{ fontSize: 11, color: C2, lineHeight: 1.55 }}>
                        Definition loaded from your annotation session in <em>{fc.lesson}</em>.
                      </div>
                      <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
                        <RotateCw size={10} color={C3} />
                      </div>
                    </div>
                  </motion.div>
                </div>
              )
            })}

            {/* Add term prompt */}
            <div style={{ width: 178, height: 105, border: `1px dashed ${BR}`, borderRadius: 5, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 6, cursor: 'pointer', color: C3, fontSize: 12 }}>
              <Plus size={16} strokeWidth={1.5} />
              <span>from annotations</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
