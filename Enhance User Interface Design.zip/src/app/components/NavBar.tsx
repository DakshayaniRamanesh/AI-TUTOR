import { LayoutDashboard, Plus, PlayCircle, Settings, Sigma } from 'lucide-react'

export type Screen = 'dashboard' | 'upload' | 'generating' | 'player'

interface NavBarProps {
  screen: Screen
  onNavigate: (s: Screen) => void
}

export function NavBar({ screen, onNavigate }: NavBarProps) {
  const items: { id: Screen; label: string; Icon: typeof LayoutDashboard }[] = [
    { id: 'dashboard', label: 'Dashboard', Icon: LayoutDashboard },
    { id: 'upload', label: 'New Lesson', Icon: Plus },
    { id: 'player', label: 'Lesson Player', Icon: PlayCircle },
  ]

  return (
    <nav style={{
      height: 52, background: '#111113',
      borderBottom: '1px solid rgba(240,234,214,0.08)',
      display: 'flex', alignItems: 'center', padding: '0 28px',
      position: 'sticky', top: 0, zIndex: 50, gap: 0,
      fontFamily: "'IBM Plex Sans', system-ui, sans-serif",
    }}>
      {/* Logo */}
      <button onClick={() => onNavigate('dashboard')} style={{
        display: 'flex', alignItems: 'center', gap: 9,
        background: 'none', border: 'none', cursor: 'pointer', padding: 0, marginRight: 36,
      }}>
        <span style={{
          width: 26, height: 26, border: '1.5px solid #d4a84b', borderRadius: 3,
          display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#d4a84b',
        }}>
          <Sigma size={13} strokeWidth={2} />
        </span>
        <span style={{
          fontFamily: "'IBM Plex Serif', Georgia, serif",
          fontSize: 14.5, fontWeight: 600, color: '#f0ead6', letterSpacing: '0.01em',
        }}>
          OptiFlow<span style={{ color: '#d4a84b' }}> Tutor</span>
        </span>
      </button>

      {/* Nav items */}
      <div style={{ display: 'flex', gap: 2, flex: 1 }}>
        {items.map(({ id, label, Icon }) => {
          const active = screen === id || (screen === 'generating' && id === 'upload')
          return (
            <button key={id} onClick={() => onNavigate(id)} style={{
              display: 'flex', alignItems: 'center', gap: 6,
              padding: '6px 13px', borderRadius: 4, border: 'none',
              background: active ? 'rgba(212,168,75,0.1)' : 'transparent',
              color: active ? '#d4a84b' : 'rgba(240,234,214,0.45)',
              fontSize: 12.5, cursor: 'pointer', letterSpacing: '0.01em',
              fontFamily: "'IBM Plex Sans', sans-serif",
              transition: 'all 0.15s',
            }}>
              <Icon size={13} strokeWidth={active ? 2 : 1.5} />
              {label}
            </button>
          )
        })}
      </div>

      {/* Right side */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginLeft: 'auto' }}>
        <span style={{ fontSize: 10, color: 'rgba(240,234,214,0.2)', letterSpacing: '0.1em' }}>v0.9.4</span>
        <div style={{ width: 1, height: 14, background: 'rgba(240,234,214,0.1)' }} />
        <button style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'rgba(240,234,214,0.3)', padding: 4 }}>
          <Settings size={14} strokeWidth={1.5} />
        </button>
        <div style={{
          width: 28, height: 28, borderRadius: '50%',
          background: 'rgba(91,135,197,0.2)', border: '1px solid rgba(91,135,197,0.3)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 11, fontWeight: 600, color: '#5b87c5', cursor: 'pointer', letterSpacing: '0.05em',
        }}>AK</div>
      </div>
    </nav>
  )
}
