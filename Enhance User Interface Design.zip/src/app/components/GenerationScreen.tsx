import { useState, useEffect, useRef } from 'react'
import { motion, AnimatePresence } from 'motion/react'
import { BookOpen, BrainCircuit, Mic2, Code2, Film, CheckCircle2, Bell, ArrowLeft, Clock, Circle } from 'lucide-react'

interface GenerationScreenProps {
  onComplete: () => void
  onBack: () => void
}

const A = '#d4a84b'
const B = '#5b87c5'
const T = '#4a9e8e'
const S1 = '#1e1e22'
const S2 = '#222228'
const BR = 'rgba(240,234,214,0.08)'
const C1 = '#f0ead6'
const C2 = '#9c9a8e'
const C3 = '#6b6960'
const FF = "'IBM Plex Sans', system-ui, sans-serif"

const STAGES = [
  { id: 'read',    label: 'Reading Document',        desc: 'Parsing structure, equations, diagrams, and section hierarchy',        Icon: BookOpen,     color: B, counterLabel: 'pages analyzed',   max: 34,   dur: 3000 },
  { id: 'plan',    label: 'Planning Lesson Structure',desc: 'Building a pedagogical sequence aligned to your focus area',           Icon: BrainCircuit, color: T, counterLabel: 'concepts mapped',   max: 18,   dur: 4500 },
  { id: 'narrate', label: 'Writing Narration',        desc: 'Drafting clear, precise explanations for each concept segment',        Icon: Mic2,         color: A, counterLabel: 'words drafted',    max: 1280, dur: 5500 },
  { id: 'animate', label: 'Generating Animation Code',desc: 'Producing Manim scenes for diagrams, proofs, and transformations',     Icon: Code2,        color: B, counterLabel: 'frames scripted', max: 2400, dur: 4000 },
  { id: 'render',  label: 'Rendering Video',          desc: 'Combining animation frames, narration audio, and chapter markers',     Icon: Film,         color: T, counterLabel: '% complete',      max: 100,  dur: 3500 },
]

function Pulse({ color }: { color: string }) {
  return (
    <span style={{ position: 'relative', display: 'inline-flex', width: 10, height: 10, flexShrink: 0 }}>
      <motion.span animate={{ scale: [1, 2, 1], opacity: [0.7, 0, 0.7] }} transition={{ duration: 1.6, repeat: Infinity }}
        style={{ position: 'absolute', inset: 0, borderRadius: '50%', background: color }} />
      <span style={{ position: 'relative', width: 10, height: 10, borderRadius: '50%', background: color }} />
    </span>
  )
}

export function GenerationScreen({ onComplete, onBack }: GenerationScreenProps) {
  const [active, setActive] = useState(0)
  const [pct, setPct] = useState(0)
  const [counter, setCounter] = useState(0)
  const [done, setDone] = useState<Set<number>>(new Set())
  const [finished, setFinished] = useState(false)
  const [notified, setNotified] = useState(false)
  const [elapsed, setElapsed] = useState(0)
  const startRef = useRef(Date.now())
  const stageStartRef = useRef(Date.now())

  const totalDur = STAGES.reduce((s, x) => s + x.dur, 0)

  useEffect(() => {
    const t = setInterval(() => setElapsed(Date.now() - startRef.current), 500)
    return () => clearInterval(t)
  }, [])

  useEffect(() => {
    if (finished) return
    stageStartRef.current = Date.now()
    const stage = STAGES[active]
    const t = setInterval(() => {
      const p = Math.min((Date.now() - stageStartRef.current) / stage.dur, 1)
      setPct(p)
      setCounter(Math.round(p * stage.max))
      if (p >= 1) {
        clearInterval(t)
        setDone(prev => new Set([...prev, active]))
        if (active < STAGES.length - 1) {
          setTimeout(() => { setActive(a => a + 1); setPct(0); setCounter(0) }, 350)
        } else {
          setTimeout(() => { setFinished(true); setTimeout(onComplete, 1100) }, 500)
        }
      }
    }, 40)
    return () => clearInterval(t)
  }, [active, finished])

  const elapsedSec = Math.floor(elapsed / 1000)
  const remaining = Math.max(Math.floor(totalDur / 1000) - elapsedSec, 0)
  const fmt = (s: number) => s >= 60 ? `${Math.floor(s / 60)}m ${s % 60}s` : `${s}s`

  return (
    <div style={{ minHeight: 'calc(100vh - 52px)', background: '#18181a', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '40px 28px', fontFamily: FF }}>
      <div style={{ width: '100%', maxWidth: 580 }}>
        {/* Back */}
        <button onClick={onBack} style={{ display: 'flex', alignItems: 'center', gap: 5, background: 'none', border: 'none', color: C3, fontSize: 12.5, cursor: 'pointer', padding: '0 0 28px', fontFamily: FF }}>
          <ArrowLeft size={13} /> Back to upload
        </button>

        {/* Header */}
        <div style={{ marginBottom: 28 }}>
          <AnimatePresence mode="wait">
            {finished ? (
              <motion.div key="done" initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }} style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <div style={{ width: 30, height: 30, borderRadius: '50%', background: 'rgba(212,168,75,0.12)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: A }}>
                  <CheckCircle2 size={17} />
                </div>
                <h1 style={{ margin: 0, fontFamily: "'IBM Plex Serif', Georgia, serif", fontSize: 22, fontWeight: 600, color: C1 }}>Lesson ready</h1>
              </motion.div>
            ) : (
              <motion.h1 key="gen" style={{ margin: 0, fontFamily: "'IBM Plex Serif', Georgia, serif", fontSize: 22, fontWeight: 600, color: C1, lineHeight: 1.3 }}>
                Generating your lesson
              </motion.h1>
            )}
          </AnimatePresence>
          <div style={{ marginTop: 8, display: 'flex', alignItems: 'center', gap: 8 }}>
            <div style={{ fontSize: 12, padding: '3px 10px', borderRadius: 3, background: S1, border: `1px solid ${BR}`, color: C2, fontFamily: "'IBM Plex Sans', monospace" }}>
              Linear Algebra — Eigenvalues &amp; Eigenvectors.pdf
            </div>
          </div>
        </div>

        {/* Pipeline */}
        <div style={{ background: S1, border: `1px solid ${BR}`, borderRadius: 8, overflow: 'hidden' }}>
          {STAGES.map((s, i) => {
            const isDone = done.has(i)
            const isActive = i === active && !finished
            const isPending = !isDone && !isActive
            const Icon = s.Icon

            return (
              <div key={s.id} style={{ borderBottom: i < STAGES.length - 1 ? `1px solid ${BR}` : 'none', position: 'relative', overflow: 'hidden' }}>
                {/* Fill bg for active */}
                {isActive && (
                  <motion.div initial={{ width: 0 }} animate={{ width: `${pct * 100}%` }}
                    style={{ position: 'absolute', inset: 0, background: `${s.color}0c`, pointerEvents: 'none', width: '0%' }} />
                )}
                {isDone && <div style={{ position: 'absolute', inset: 0, background: 'rgba(240,234,214,0.015)', pointerEvents: 'none' }} />}

                <div style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '15px 20px', position: 'relative', zIndex: 1 }}>
                  {/* Icon */}
                  <div style={{
                    width: 36, height: 36, borderRadius: 5, flexShrink: 0,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    background: isDone ? 'rgba(212,168,75,0.09)' : isActive ? `${s.color}18` : S2,
                    border: `1px solid ${isDone ? 'rgba(212,168,75,0.22)' : isActive ? `${s.color}40` : BR}`,
                    color: isDone ? A : isActive ? s.color : C3,
                    transition: 'all 0.3s',
                  }}>
                    {isDone ? <CheckCircle2 size={15} /> : <Icon size={15} strokeWidth={1.5} />}
                  </div>

                  {/* Text */}
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 2 }}>
                      <span style={{ fontSize: 13, fontWeight: isActive ? 500 : 400, color: isDone ? C2 : isActive ? C1 : C3, transition: 'color 0.3s' }}>
                        {s.label}
                      </span>
                      {isActive && <Pulse color={s.color} />}
                    </div>
                    <div style={{ fontSize: 11.5, color: C3, lineHeight: 1.4 }}>{s.desc}</div>
                  </div>

                  {/* Counter */}
                  <div style={{ textAlign: 'right', flexShrink: 0, minWidth: 60 }}>
                    {isDone && (
                      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
                        <div style={{ fontSize: 14, fontWeight: 500, color: A, fontFamily: "'IBM Plex Sans', monospace" }}>{s.max.toLocaleString()}</div>
                        <div style={{ fontSize: 10, color: C3 }}>{s.counterLabel}</div>
                      </motion.div>
                    )}
                    {isActive && (
                      <div>
                        <div style={{ fontSize: 14, fontWeight: 500, color: s.color, fontFamily: "'IBM Plex Sans', monospace" }}>{counter.toLocaleString()}</div>
                        <div style={{ fontSize: 10, color: C3 }}>{s.counterLabel}</div>
                      </div>
                    )}
                    {isPending && <Circle size={13} color={C3} strokeWidth={1} />}
                  </div>
                </div>

                {/* Bottom fill bar */}
                {isActive && (
                  <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, height: 1.5, background: BR }}>
                    <motion.div initial={{ width: 0 }} animate={{ width: `${pct * 100}%` }} transition={{ ease: 'linear' }}
                      style={{ height: '100%', background: s.color }} />
                  </div>
                )}
              </div>
            )
          })}
        </div>

        {/* Footer */}
        <div style={{ marginTop: 18, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, color: C3, fontSize: 12 }}>
            <Clock size={12} />
            {finished
              ? <span style={{ color: A }}>Complete — opening player…</span>
              : <span>Est. <span style={{ color: C2 }}>{fmt(remaining)}</span> remaining</span>
            }
          </div>
          {!finished && (
            <motion.button whileTap={{ scale: 0.97 }} onClick={() => setNotified(p => !p)} style={{
              display: 'flex', alignItems: 'center', gap: 6,
              padding: '7px 13px', background: notified ? 'rgba(91,135,197,0.1)' : 'transparent',
              border: `1px solid ${notified ? 'rgba(91,135,197,0.3)' : BR}`,
              borderRadius: 4, color: notified ? B : C3, fontSize: 12,
              cursor: 'pointer', transition: 'all 0.2s', fontFamily: FF,
            }}>
              <Bell size={12} />
              {notified ? 'Will notify you' : 'Notify when ready'}
            </motion.button>
          )}
        </div>

        {/* Info strip */}
        {!finished && (
          <div style={{ marginTop: 28, padding: '13px 16px', background: 'rgba(91,135,197,0.07)', border: '1px solid rgba(91,135,197,0.14)', borderRadius: 5, fontSize: 12.5, color: C2, lineHeight: 1.65 }}>
            <span style={{ color: B, fontWeight: 500 }}>What's happening:</span> Each stage is genuinely sequential — the narration depends on the lesson plan, and the animation code depends on the narration. Progress fills left-to-right as each stage completes.
          </div>
        )}
      </div>
    </div>
  )
}
