import { useState, useRef, useEffect } from 'react'
import { motion, AnimatePresence } from 'motion/react'
import { Play, Pause, Volume2, Maximize2, Pencil, ChevronLeft, ChevronRight, MessageSquarePlus, X, RotateCw } from 'lucide-react'
import { Panel, PanelGroup, PanelResizeHandle } from 'react-resizable-panels'

interface PlayerScreenProps { onBack: () => void }

const A = '#d4a84b'
const B = '#5b87c5'
const S1 = '#1e1e22'
const S2 = '#222228'
const S3 = '#28282e'
const BR = 'rgba(240,234,214,0.08)'
const BRS = 'rgba(240,234,214,0.13)'
const C1 = '#f0ead6'
const C2 = '#9c9a8e'
const C3 = '#6b6960'
const FF = "'IBM Plex Sans', system-ui, sans-serif"
const TOTAL = 934

const CHAPTERS = [
  { t: 0,   label: 'Introduction',         pct: 0    },
  { t: 112, label: 'What are Eigenvalues?', pct: 12   },
  { t: 264, label: 'Geometric Intuition',   pct: 28.3 },
  { t: 463, label: 'Computing Eigenvalues', pct: 49.6 },
  { t: 654, label: 'Diagonalization',       pct: 70   },
  { t: 812, label: 'Applications',          pct: 86.9 },
]

const DOTS = [
  { p: 50.2, n: 8 }, { p: 51.8, n: 14 }, { p: 52.6, n: 6 },
  { p: 53.1, n: 11 }, { p: 54.4, n: 5 }, { p: 55.0, n: 9 },
  { p: 29.1, n: 4 }, { p: 30.5, n: 3 }, { p: 71.2, n: 2 }, { p: 72.4, n: 6 },
]

const TERMS = [
  { term: 'Eigenvalue',             def: 'A scalar λ such that Av = λv for some non-zero vector v. Represents how the transformation scales along the eigenvector direction.',   ts: '4:24' },
  { term: 'Eigenvector',            def: 'A non-zero vector that only gets scaled (not rotated) by transformation A. The direction is preserved; magnitude changes by λ.',         ts: '4:51' },
  { term: 'Determinant',            def: 'A scalar encoding how much a linear map scales volume. det(A) = 0 means the transformation collapses space to a lower dimension.',       ts: '7:38' },
  { term: 'Characteristic Polynomial', def: 'The polynomial det(A − λI) = 0 whose roots are the eigenvalues of A. Its degree equals the matrix dimension.',                      ts: '8:12' },
  { term: 'Diagonalization',        def: 'Writing A = PDP⁻¹ where D is diagonal and P is the matrix of eigenvectors. Possible when A has n linearly independent eigenvectors.',  ts: '11:05' },
]

const PDF = [
  { h: '5.1  Introduction to Eigenvalues', text: 'The concept of eigenvalues and eigenvectors is central to linear algebra and its many applications. Given a square matrix A, we seek vectors that are merely stretched or compressed — not rotated — by the transformation represented by A.' },
  { h: null, text: 'Formally, a scalar λ is called an eigenvalue of A if there exists a non-zero vector v such that Av = λv. This can be rewritten as (A − λI)v = 0, which has a non-trivial solution only when det(A − λI) = 0.', active: true },
  { h: null, text: 'The polynomial p(λ) = det(A − λI) is called the characteristic polynomial of A. Its degree equals the matrix dimension n. The roots — real or complex — are the eigenvalues.' },
  { h: '5.2  Geometric Interpretation', text: 'Geometrically, an eigenvector defines a direction in space that is invariant under A. Points along this direction map to points along the same direction. The eigenvalue λ gives the scaling factor.' },
]

function MathViz({ t }: { t: number }) {
  const p = t / TOTAL
  const ang = p * 80
  const rad = (ang * Math.PI) / 180
  const vx = 200 + Math.cos(rad) * 95
  const vy = 140 - Math.sin(rad) * 95
  return (
    <svg viewBox="0 0 400 280" style={{ width: '100%', height: '100%', display: 'block', background: '#0c0c0e' }}>
      {/* Grid */}
      {Array.from({ length: 9 }).map((_, i) => <line key={`h${i}`} x1={0} y1={i * 36} x2={400} y2={i * 36} stroke="rgba(240,234,214,0.03)" strokeWidth="0.5" />)}
      {Array.from({ length: 12 }).map((_, i) => <line key={`v${i}`} x1={i * 37} y1={0} x2={i * 37} y2={280} stroke="rgba(240,234,214,0.03)" strokeWidth="0.5" />)}
      {/* Axes */}
      <line x1="200" y1="30" x2="200" y2="252" stroke="rgba(240,234,214,0.22)" strokeWidth="0.8" />
      <line x1="38" y1="140" x2="362" y2="140" stroke="rgba(240,234,214,0.22)" strokeWidth="0.8" />
      <polygon points="200,26 196.5,35 203.5,35" fill="rgba(240,234,214,0.25)" />
      <polygon points="365,140 355,136.5 355,143.5" fill="rgba(240,234,214,0.25)" />
      {/* Matrix label */}
      <text x="16" y="22" fill="rgba(240,234,214,0.35)" fontSize="10.5" fontFamily="'IBM Plex Sans', monospace">A = [[3,1],[0,2]]</text>
      {/* Eigenvector v1 (amber) */}
      {p > 0.08 && (
        <>
          <line x1="200" y1="140" x2={vx} y2={vy} stroke={A} strokeWidth="2" strokeLinecap="round" />
          <polygon points={`${vx},${vy} ${vx - Math.cos(rad) * 14 - Math.sin(rad) * 7},${vy + Math.sin(rad) * 14 - Math.cos(rad) * 7} ${vx - Math.cos(rad) * 14 + Math.sin(rad) * 7},${vy + Math.sin(rad) * 14 + Math.cos(rad) * 7}`} fill={A} />
          <text x={vx + 8} y={vy - 6} fill={A} fontSize="12.5" fontFamily="'IBM Plex Serif', serif">λ₁v₁</text>
        </>
      )}
      {/* Eigenvector v2 (blue dashed) */}
      {p > 0.25 && (
        <>
          <line x1="200" y1="140" x2="84" y2="62" stroke={B} strokeWidth="1.5" strokeDasharray="5 3" strokeLinecap="round" />
          <text x="72" y="54" fill={B} fontSize="12" fontFamily="'IBM Plex Serif', serif">λ₂v₂</text>
        </>
      )}
      {/* Chapter indicator */}
      {p > 0.49 && p < 0.7 && (
        <text x="16" y="272" fill={A} fontSize="10" fontFamily={FF} opacity="0.65">Computing eigenvalues…  det(A − λI) = 0</text>
      )}
    </svg>
  )
}

function GlossCard({ term, def, ts }: { term: string; def: string; ts: string }) {
  const [flipped, setFlipped] = useState(false)
  return (
    <div onClick={() => setFlipped(p => !p)} style={{ perspective: 900, width: 178, height: 108, flexShrink: 0, cursor: 'pointer' }}>
      <motion.div animate={{ rotateY: flipped ? 180 : 0 }} transition={{ duration: 0.42, ease: [0.25, 0.46, 0.45, 0.94] }}
        style={{ width: '100%', height: '100%', position: 'relative', transformStyle: 'preserve-3d' }}>
        <div style={{ position: 'absolute', inset: 0, backfaceVisibility: 'hidden', background: S2, border: `1px solid ${BRS}`, borderRadius: 5, padding: '11px 13px', display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
          <div style={{ fontSize: 13.5, fontFamily: "'IBM Plex Serif', Georgia, serif", fontWeight: 500, color: C1, lineHeight: 1.3 }}>{term}</div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <span style={{ fontSize: 10, color: C3 }}>tap to define</span>
            <span style={{ fontSize: 10, color: A, fontFamily: 'monospace' }}>{ts}</span>
          </div>
        </div>
        <div style={{ position: 'absolute', inset: 0, backfaceVisibility: 'hidden', transform: 'rotateY(180deg)', background: 'rgba(212,168,75,0.06)', border: '1px solid rgba(212,168,75,0.2)', borderRadius: 5, padding: '9px 11px', display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
          <div style={{ fontSize: 10.5, color: C2, lineHeight: 1.55, overflow: 'hidden', display: '-webkit-box', WebkitLineClamp: 4, WebkitBoxOrient: 'vertical' }}>{def}</div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 4 }}>
            <span style={{ fontSize: 9.5, color: C3 }}>→ jump to {ts}</span>
            <RotateCw size={10} color={C3} />
          </div>
        </div>
      </motion.div>
    </div>
  )
}

function Scrubber({ t, onSeek }: { t: number; onSeek: (v: number) => void }) {
  const trackRef = useRef<HTMLDivElement>(null)
  const pct = (t / TOTAL) * 100
  const [hovDot, setHovDot] = useState<{ p: number; n: number } | null>(null)
  const [hovChap, setHovChap] = useState<string | null>(null)

  const seek = (e: React.MouseEvent) => {
    if (!trackRef.current) return
    const r = trackRef.current.getBoundingClientRect()
    onSeek(Math.max(0, Math.min(1, (e.clientX - r.left) / r.width)) * TOTAL)
  }

  return (
    <div style={{ position: 'relative', paddingBottom: 22 }}>
      {/* Chapter labels */}
      <div style={{ position: 'relative', height: 16, marginBottom: 2 }}>
        {CHAPTERS.map(c => (
          <div key={c.t} onMouseEnter={() => setHovChap(c.label)} onMouseLeave={() => setHovChap(null)} onClick={() => onSeek(c.t)}
            style={{ position: 'absolute', left: `${c.pct}%`, transform: 'translateX(-50%)', fontSize: 9.5, color: hovChap === c.label ? C1 : C3, whiteSpace: 'nowrap', cursor: 'pointer', transition: 'color 0.15s', letterSpacing: '0.01em' }}>
            {c.label}
          </div>
        ))}
      </div>

      {/* Track */}
      <div ref={trackRef} onClick={seek} style={{ height: 3, background: 'rgba(240,234,214,0.09)', borderRadius: 2, cursor: 'pointer', position: 'relative' }}>
        {/* Played fill */}
        <div style={{ position: 'absolute', top: 0, left: 0, height: '100%', width: `${pct}%`, background: A, borderRadius: 2 }} />
        {/* Chapter ticks */}
        {CHAPTERS.map(c => (
          <div key={c.t} style={{ position: 'absolute', top: -3, left: `${c.pct}%`, transform: 'translateX(-50%)', width: 1.5, height: 9, background: c.pct <= pct ? A : 'rgba(240,234,214,0.2)', borderRadius: 1 }} />
        ))}
        {/* Confusion dots */}
        {DOTS.map((d, i) => (
          <div key={i} onMouseEnter={() => setHovDot(d)} onMouseLeave={() => setHovDot(null)}
            style={{ position: 'absolute', top: '50%', left: `${d.p}%`, transform: 'translate(-50%,-50%)', width: Math.max(3, Math.min(7, d.n * 0.5)), height: Math.max(3, Math.min(7, d.n * 0.5)), borderRadius: '50%', background: `rgba(91,135,197,${Math.min(0.85, 0.3 + d.n * 0.04)})`, cursor: 'pointer', zIndex: 2 }} />
        ))}
        {/* Thumb */}
        <div style={{ position: 'absolute', top: '50%', left: `${pct}%`, transform: 'translate(-50%,-50%)', width: 11, height: 11, borderRadius: '50%', background: A, border: '1.5px solid #18181a', zIndex: 3 }} />
      </div>

      {/* Dot tooltip */}
      <AnimatePresence>
        {hovDot && (
          <motion.div initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
            style={{ position: 'absolute', bottom: 0, left: `${hovDot.p}%`, transform: 'translateX(-50%)', background: S3, border: `1px solid ${BRS}`, borderRadius: 4, padding: '4px 8px', fontSize: 10, color: C2, whiteSpace: 'nowrap', pointerEvents: 'none', zIndex: 10 }}>
            {hovDot.n} students paused here
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

export function PlayerScreen({ onBack }: PlayerScreenProps) {
  const [playing, setPlaying] = useState(false)
  const [t, setT] = useState(463)
  const [annotMode, setAnnotMode] = useState(false)
  const [annotInput, setAnnotInput] = useState(false)
  const [annotText, setAnnotText] = useState('')
  const ivRef = useRef<ReturnType<typeof setInterval> | null>(null)

  const fmt = (s: number) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`
  const activePdf = t / TOTAL < 0.28 ? 0 : t / TOTAL < 0.49 ? 1 : t / TOTAL < 0.7 ? 2 : 3

  const togglePlay = () => {
    if (playing) { clearInterval(ivRef.current!); setPlaying(false) }
    else {
      ivRef.current = setInterval(() => setT(p => { if (p >= TOTAL) { clearInterval(ivRef.current!); setPlaying(false); return p } return p + 1 }), 1000)
      setPlaying(true)
    }
  }
  useEffect(() => () => { clearInterval(ivRef.current!) }, [])

  return (
    <div style={{ height: 'calc(100vh - 52px)', display: 'flex', flexDirection: 'column', background: '#18181a', overflow: 'hidden', fontFamily: FF }}>
      {/* Breadcrumb */}
      <div style={{ padding: '9px 20px', borderBottom: `1px solid ${BR}`, display: 'flex', alignItems: 'center', gap: 10, flexShrink: 0 }}>
        <button onClick={onBack} style={{ display: 'flex', alignItems: 'center', gap: 5, background: 'none', border: 'none', color: C3, fontSize: 12, cursor: 'pointer', padding: 0, fontFamily: FF }}>
          <ChevronLeft size={13} /> Dashboard
        </button>
        <span style={{ color: BRS, fontSize: 12 }}>/</span>
        <span style={{ fontSize: 12.5, color: C2, fontFamily: "'IBM Plex Serif', Georgia, serif" }}>Eigenvalues &amp; Eigenvectors</span>
        <div style={{ marginLeft: 'auto', fontSize: 10.5, padding: '2px 9px', borderRadius: 3, background: 'rgba(212,168,75,0.1)', border: '1px solid rgba(212,168,75,0.2)', color: A }}>Mathematics</div>
      </div>

      {/* Split view */}
      <div style={{ flex: 1, overflow: 'hidden', minHeight: 0 }}>
        <PanelGroup direction="horizontal" style={{ height: '100%' }}>
          {/* Video */}
          <Panel defaultSize={60} minSize={38}>
            <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: '#111113' }}>
              {/* Video area */}
              <div style={{ flex: 1, position: 'relative', minHeight: 0, overflow: 'hidden', cursor: annotMode ? 'crosshair' : 'default' }}
                onClick={() => { if (annotMode) setAnnotInput(true) }}>
                <MathViz t={t} />

                {/* Annotation mode border overlay */}
                <AnimatePresence>
                  {annotMode && (
                    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                      style={{ position: 'absolute', inset: 0, border: '2px dashed rgba(212,168,75,0.4)', pointerEvents: 'none' }}>
                      <div style={{ position: 'absolute', top: 10, left: '50%', transform: 'translateX(-50%)', background: 'rgba(212,168,75,0.14)', border: '1px solid rgba(212,168,75,0.28)', borderRadius: 4, padding: '5px 12px', fontSize: 11.5, color: A, whiteSpace: 'nowrap' }}>
                        Click anywhere to annotate
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>

                {/* Annotation input */}
                <AnimatePresence>
                  {annotInput && (
                    <motion.div initial={{ opacity: 0, scale: 0.93, y: 8 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.93, y: 8 }}
                      style={{ position: 'absolute', bottom: 18, left: '50%', transform: 'translateX(-50%)', width: 310, background: S2, border: '1px solid rgba(212,168,75,0.3)', borderRadius: 6, padding: 14, zIndex: 20 }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
                        <span style={{ fontSize: 12, color: C2 }}>Question at <span style={{ color: A, fontFamily: 'monospace' }}>{fmt(t)}</span></span>
                        <button onClick={() => { setAnnotInput(false); setAnnotMode(false) }} style={{ background: 'none', border: 'none', cursor: 'pointer', color: C3 }}><X size={14} /></button>
                      </div>
                      <textarea value={annotText} onChange={e => setAnnotText(e.target.value)} placeholder="What don't you understand at this moment?" autoFocus rows={3}
                        style={{ width: '100%', background: S3, border: `1px solid ${BR}`, borderRadius: 4, padding: '9px 11px', color: C1, fontSize: 12.5, resize: 'none', outline: 'none', fontFamily: FF, boxSizing: 'border-box', lineHeight: 1.55 }} />
                      <button onClick={() => { setAnnotInput(false); setAnnotMode(false); setAnnotText('') }}
                        style={{ marginTop: 10, width: '100%', padding: 8, background: A, border: 'none', borderRadius: 4, color: '#18181a', fontSize: 12.5, fontWeight: 600, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, fontFamily: FF }}>
                        <MessageSquarePlus size={13} /> Generate explanation clip
                      </button>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* Controls */}
              <div style={{ background: '#0c0c0e', borderTop: `1px solid ${BR}`, padding: '9px 16px 11px', flexShrink: 0 }}>
                <Scrubber t={t} onSeek={setT} />
                <div style={{ display: 'flex', alignItems: 'center', gap: 11 }}>
                  <button onClick={togglePlay} style={{ width: 32, height: 32, borderRadius: '50%', background: A, border: 'none', color: '#18181a', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', flexShrink: 0 }}>
                    {playing ? <Pause size={13} fill="#18181a" /> : <Play size={13} fill="#18181a" />}
                  </button>
                  <span style={{ fontSize: 11.5, color: C2, fontFamily: 'monospace', letterSpacing: '0.04em', flexShrink: 0 }}>
                    {fmt(t)}<span style={{ color: C3 }}> / {fmt(TOTAL)}</span>
                  </span>
                  <Volume2 size={13} color={C3} style={{ flexShrink: 0 }} />
                  <div style={{ display: 'flex', gap: 3, marginLeft: 'auto' }}>
                    <button onClick={() => { const p = [...CHAPTERS].reverse().find(c => c.t < t - 2); if (p) setT(p.t) }}
                      style={{ background: S3, border: `1px solid ${BR}`, borderRadius: 3, padding: '4px 7px', color: C2, cursor: 'pointer', display: 'flex', alignItems: 'center' }}>
                      <ChevronLeft size={12} />
                    </button>
                    <button onClick={() => { const n = CHAPTERS.find(c => c.t > t + 2); if (n) setT(n.t) }}
                      style={{ background: S3, border: `1px solid ${BR}`, borderRadius: 3, padding: '4px 7px', color: C2, cursor: 'pointer', display: 'flex', alignItems: 'center' }}>
                      <ChevronRight size={12} />
                    </button>
                  </div>
                  <button onClick={() => { setAnnotMode(p => !p); setAnnotInput(false) }}
                    style={{ display: 'flex', alignItems: 'center', gap: 5, padding: '5px 10px', background: annotMode ? 'rgba(212,168,75,0.13)' : S3, border: `1px solid ${annotMode ? 'rgba(212,168,75,0.35)' : BR}`, borderRadius: 4, color: annotMode ? A : C3, fontSize: 11.5, cursor: 'pointer', transition: 'all 0.2s', fontFamily: FF }}>
                    <Pencil size={11} /> Annotate
                  </button>
                  <Maximize2 size={13} color={C3} style={{ cursor: 'pointer', flexShrink: 0 }} />
                </div>
              </div>
            </div>
          </Panel>

          <PanelResizeHandle style={{ width: 4, background: BR, cursor: 'col-resize' }} />

          {/* PDF */}
          <Panel defaultSize={40} minSize={24}>
            <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: S1, borderLeft: `1px solid ${BR}` }}>
              <div style={{ padding: '9px 16px', borderBottom: `1px solid ${BR}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexShrink: 0 }}>
                <span style={{ fontSize: 10.5, color: C3, letterSpacing: '0.07em' }}>SOURCE PDF</span>
                <span style={{ fontSize: 10.5, color: C3, fontFamily: 'monospace' }}>p. 214 of 412</span>
              </div>
              <div style={{ flex: 1, overflowY: 'auto', padding: '18px 20px', scrollbarWidth: 'thin', scrollbarColor: `${BRS} transparent` }}>
                {/* PDF meta */}
                <div style={{ fontSize: 10, color: C3, letterSpacing: '0.06em', marginBottom: 14, borderBottom: `1px solid ${BR}`, paddingBottom: 10, display: 'flex', justifyContent: 'space-between' }}>
                  <span>Linear Algebra — Gilbert Strang</span><span>Chapter 5</span>
                </div>
                {PDF.map((p, i) => {
                  const isAct = i === activePdf
                  return (
                    <div key={i} style={{ marginBottom: 15, padding: isAct ? '12px 14px' : '0', background: isAct ? 'rgba(212,168,75,0.055)' : 'transparent', borderLeft: isAct ? `2.5px solid ${A}` : '2.5px solid transparent', borderRadius: isAct ? '0 4px 4px 0' : 0, transition: 'all 0.35s' }}>
                      {p.h && <h3 style={{ margin: '0 0 7px', fontFamily: "'IBM Plex Serif', Georgia, serif", fontSize: 14, fontWeight: 600, color: isAct ? C1 : C2, lineHeight: 1.4 }}>{p.h}</h3>}
                      <p style={{ margin: 0, fontSize: 13, lineHeight: 1.75, color: isAct ? C1 : C2, fontFamily: "'IBM Plex Serif', Georgia, serif" }}>{p.text}</p>
                    </div>
                  )
                })}
                {/* Equation block */}
                <div style={{ margin: '18px 0', padding: '13px 18px', background: S2, border: `1px solid ${BR}`, borderRadius: 4, textAlign: 'center', fontFamily: "'IBM Plex Serif', Georgia, serif", fontSize: 15, color: C1, letterSpacing: '0.02em', lineHeight: 2.1 }}>
                  det(A − λI) = 0
                  <br /><span style={{ fontSize: 11.5, color: C3 }}>Characteristic equation</span>
                </div>
                <p style={{ margin: 0, fontSize: 13, lineHeight: 1.75, color: C2, fontFamily: "'IBM Plex Serif', Georgia, serif" }}>
                  For a 2×2 matrix, this yields a quadratic in λ. For an n×n matrix, the characteristic polynomial has degree n and its roots — real or complex — are the eigenvalues.
                </p>
              </div>
            </div>
          </Panel>
        </PanelGroup>
      </div>

      {/* Glossary rail */}
      <div style={{ borderTop: `1px solid ${BR}`, padding: '9px 16px 12px', flexShrink: 0, background: '#111113' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 9 }}>
          <span style={{ fontSize: 10.5, color: C3, letterSpacing: '0.07em' }}>LESSON GLOSSARY · {TERMS.length} terms encountered</span>
          <span style={{ fontSize: 10, color: C3 }}>tap to flip</span>
        </div>
        <div style={{ display: 'flex', gap: 9, overflowX: 'auto', scrollbarWidth: 'none', paddingBottom: 2 }}>
          {TERMS.map(t => <GlossCard key={t.term} {...t} />)}
        </div>
      </div>
    </div>
  )
}
