import { useState, useRef } from 'react'
import { motion } from 'motion/react'
import { Upload, FileText, ArrowRight, Clock, Play, ChevronRight } from 'lucide-react'

interface UploadScreenProps {
  onGenerate: () => void
  onOpenLesson: () => void
}

const A = '#d4a84b'   // amber
const B = '#5b87c5'   // blue
const T = '#4a9e8e'   // teal
const S1 = '#1e1e22'  // surface 1
const S2 = '#222228'  // surface 2
const S3 = '#28282e'  // surface 3
const BR = 'rgba(240,234,214,0.08)'
const BRS = 'rgba(240,234,214,0.14)'
const C1 = '#f0ead6'  // text primary
const C2 = '#9c9a8e'  // text secondary
const C3 = '#6b6960'  // text tertiary

const DIFFICULTY = [
  { v: 0, label: 'Foundational', sub: 'Build from first principles' },
  { v: 1, label: 'Standard', sub: 'Assumes prior exposure' },
  { v: 2, label: 'Rigorous', sub: 'Full mathematical depth' },
]

const LESSONS = [
  { id: 1, title: 'Fourier Transforms', source: 'Signals & Systems — Ch. 4', subject: 'Engineering', subjectColor: B, duration: '18:42', progress: 72, shape: 'wave' },
  { id: 2, title: 'Differential Equations', source: 'Calculus III — Lecture 9', subject: 'Mathematics', subjectColor: A, duration: '24:15', progress: 100, shape: 'field' },
  { id: 3, title: 'Quantum States', source: 'Intro Quantum Mechanics', subject: 'Physics', subjectColor: T, duration: '31:07', progress: 45, shape: 'wave2' },
  { id: 4, title: 'Gradient Descent', source: 'ML Fundamentals — Ch. 5', subject: 'CS / ML', subjectColor: '#c87941', duration: '22:54', progress: 100, shape: 'contour' },
]

function GridSVG() {
  return (
    <svg style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', pointerEvents: 'none' }}>
      <defs>
        <pattern id="ofgrid-sm" width="32" height="32" patternUnits="userSpaceOnUse">
          <path d="M32 0L0 0 0 32" fill="none" stroke="rgba(240,234,214,0.045)" strokeWidth="0.5" />
        </pattern>
        <pattern id="ofgrid-lg" width="160" height="160" patternUnits="userSpaceOnUse">
          <rect width="160" height="160" fill="url(#ofgrid-sm)" />
          <path d="M160 0L0 0 0 160" fill="none" stroke="rgba(240,234,214,0.09)" strokeWidth="0.5" />
        </pattern>
        <radialGradient id="ofvignette" cx="50%" cy="50%" r="50%">
          <stop offset="30%" stopColor="transparent" />
          <stop offset="100%" stopColor="#1e1e22" />
        </radialGradient>
      </defs>
      <rect width="100%" height="100%" fill="url(#ofgrid-lg)" />
      <rect width="100%" height="100%" fill="url(#ofvignette)" />
      {/* Axes */}
      <line x1="50%" y1="8%" x2="50%" y2="92%" stroke="rgba(240,234,214,0.1)" strokeWidth="0.7" />
      <line x1="8%" y1="50%" x2="92%" y2="50%" stroke="rgba(240,234,214,0.1)" strokeWidth="0.7" />
      {/* Arrow heads */}
      <polygon points="50%,7% 49.5%,10% 50.5%,10%" fill="rgba(240,234,214,0.2)" />
      <polygon points="93%,50% 90%,49.5% 90%,50.5%" fill="rgba(240,234,214,0.2)" />
      {/* Sample eigenvector */}
      <line x1="50%" y1="50%" x2="62%" y2="36%" stroke="rgba(212,168,75,0.3)" strokeWidth="1.3" />
      <polygon points="62%,36% 60.5%,38.5% 63%,38.8%" fill="rgba(212,168,75,0.4)" />
      <line x1="50%" y1="50%" x2="38%" y2="64%" stroke="rgba(91,135,197,0.25)" strokeWidth="1" strokeDasharray="5 3" />
    </svg>
  )
}

function Thumbnail({ shape, progress }: { shape: string; progress: number }) {
  return (
    <div style={{ width: '100%', height: 90, background: '#0e0e10', position: 'relative', overflow: 'hidden' }}>
      <svg style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }} viewBox="0 0 200 90">
        <defs>
          <pattern id={`tg-${shape}`} width="20" height="20" patternUnits="userSpaceOnUse">
            <path d="M20 0L0 0 0 20" fill="none" stroke="rgba(240,234,214,0.1)" strokeWidth="0.5" />
          </pattern>
        </defs>
        <rect width="200" height="90" fill={`url(#tg-${shape})`} />
        {shape === 'wave' && (
          <>
            <path d="M10,45 Q30,20 50,45 Q70,70 90,45 Q110,20 130,45 Q150,70 170,45 Q190,20 200,45" fill="none" stroke={A} strokeWidth="1.5" opacity="0.7" />
            <path d="M10,55 Q40,30 70,55 Q100,80 130,55 Q160,30 200,55" fill="none" stroke={B} strokeWidth="1" opacity="0.4" />
          </>
        )}
        {shape === 'field' && Array.from({ length: 5 }).map((_, i) =>
          Array.from({ length: 4 }).map((_, j) => (
            <line key={`${i}${j}`} x1={20 + i * 40} y1={18 + j * 18} x2={20 + i * 40 + 12} y2={18 + j * 18 - (i - 2) * 3} stroke="rgba(240,234,214,0.45)" strokeWidth="1" />
          ))
        )}
        {shape === 'wave2' && (
          <path d="M10,55 Q35,15 60,45 Q85,75 110,35 Q135,5 160,40 Q185,65 200,50" fill="none" stroke={T} strokeWidth="1.5" opacity="0.65" />
        )}
        {shape === 'contour' && [36, 26, 18, 11].map((r, i) => (
          <ellipse key={i} cx="100" cy="45" rx={r + 16} ry={r * 0.55 + 8} fill="none" stroke={i === 0 ? `rgba(212,168,75,0.5)` : 'rgba(240,234,214,0.14)'} strokeWidth="0.8" />
        ))}
        {shape === 'contour' && <circle cx="100" cy="45" r="3" fill={A} opacity="0.9" />}
      </svg>
      {progress < 100 && (
        <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, height: 2, background: 'rgba(240,234,214,0.07)' }}>
          <div style={{ height: '100%', width: `${progress}%`, background: A }} />
        </div>
      )}
    </div>
  )
}

export function UploadScreen({ onGenerate, onOpenLesson }: UploadScreenProps) {
  const [dragging, setDragging] = useState(false)
  const [file, setFile] = useState<string | null>(null)
  const [question, setQuestion] = useState('')
  const [difficulty, setDifficulty] = useState(1)
  const ref = useRef<HTMLInputElement>(null)
  const FF = "'IBM Plex Sans', system-ui, sans-serif"

  return (
    <div style={{ minHeight: 'calc(100vh - 52px)', background: '#18181a', padding: '48px 28px 72px', display: 'flex', flexDirection: 'column', alignItems: 'center', fontFamily: FF }}>
      {/* Page header */}
      <div style={{ width: '100%', maxWidth: 760, marginBottom: 32 }}>
        <h1 style={{ margin: 0, fontFamily: "'IBM Plex Serif', Georgia, serif", fontSize: 28, fontWeight: 600, color: C1, lineHeight: 1.3 }}>
          New Lesson
        </h1>
        <p style={{ margin: '6px 0 0', color: C2, fontSize: 14.5, lineHeight: 1.65 }}>
          Upload a PDF — textbook chapter, lecture notes, or past paper — and OptiFlow generates a narrated animated lesson in minutes.
        </p>
      </div>

      {/* Drop zone */}
      <motion.div
        animate={{ scale: dragging ? 1.01 : 1 }}
        transition={{ duration: 0.15 }}
        onDragOver={e => { e.preventDefault(); setDragging(true) }}
        onDragLeave={() => setDragging(false)}
        onDrop={e => { e.preventDefault(); setDragging(false); const f = e.dataTransfer.files[0]; if (f) setFile(f.name) }}
        onClick={() => ref.current?.click()}
        style={{
          width: '100%', maxWidth: 760, height: 300, position: 'relative',
          background: S1, borderRadius: 6, overflow: 'hidden', cursor: 'pointer',
          border: `1.5px dashed ${dragging ? A : BRS}`,
          display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 12,
          transition: 'border-color 0.2s, background 0.2s',
        }}
      >
        <GridSVG />
        <input ref={ref} type="file" accept=".pdf" style={{ display: 'none' }} onChange={e => { if (e.target.files?.[0]) setFile(e.target.files[0].name) }} />

        {file ? (
          <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10, zIndex: 1 }}>
            <div style={{ width: 48, height: 48, background: 'rgba(212,168,75,0.12)', border: '1px solid rgba(212,168,75,0.3)', borderRadius: 6, display: 'flex', alignItems: 'center', justifyContent: 'center', color: A }}>
              <FileText size={22} />
            </div>
            <div style={{ textAlign: 'center' }}>
              <div style={{ color: C1, fontSize: 14, fontWeight: 500 }}>{file}</div>
              <div style={{ color: C3, fontSize: 11.5, marginTop: 3 }}>Click to replace</div>
            </div>
          </motion.div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10, zIndex: 1 }}>
            <div style={{ width: 52, height: 52, background: S2, border: `1px solid ${BRS}`, borderRadius: 6, display: 'flex', alignItems: 'center', justifyContent: 'center', color: C3 }}>
              <Upload size={22} strokeWidth={1.5} />
            </div>
            <div style={{ textAlign: 'center' }}>
              <div style={{ color: C1, fontSize: 15 }}>Drop your PDF here</div>
              <div style={{ color: C3, fontSize: 12.5, marginTop: 4 }}>or click to browse — textbook chapters, lecture notes, problem sets</div>
            </div>
          </div>
        )}
      </motion.div>

      {/* Controls */}
      <div style={{ width: '100%', maxWidth: 760, marginTop: 18, display: 'grid', gridTemplateColumns: '1fr auto', gap: 16, alignItems: 'start' }}>
        {/* Focus area */}
        <div>
          <label style={{ display: 'block', color: C3, fontSize: 10.5, letterSpacing: '0.08em', marginBottom: 8 }}>FOCUS AREA <span style={{ fontSize: 10 }}>(optional)</span></label>
          <textarea
            value={question} onChange={e => setQuestion(e.target.value)}
            placeholder="e.g. I struggle with the geometric intuition for eigenvectors — focus there."
            rows={3}
            style={{
              width: '100%', background: S1, border: `1px solid ${BR}`, borderRadius: 5,
              padding: '11px 14px', color: C1, fontSize: 13.5, lineHeight: 1.65,
              resize: 'none', outline: 'none', fontFamily: FF, boxSizing: 'border-box',
              transition: 'border-color 0.2s',
            }}
            onFocus={e => (e.target.style.borderColor = 'rgba(212,168,75,0.35)')}
            onBlur={e => (e.target.style.borderColor = BR)}
          />
        </div>

        {/* Depth control */}
        <div style={{ minWidth: 205 }}>
          <label style={{ display: 'block', color: C3, fontSize: 10.5, letterSpacing: '0.08em', marginBottom: 8 }}>DEPTH</label>
          <div style={{ background: S1, border: `1px solid ${BR}`, borderRadius: 5, overflow: 'hidden' }}>
            {DIFFICULTY.map(d => (
              <button key={d.v} onClick={() => setDifficulty(d.v)} style={{
                width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                padding: '10px 13px', background: difficulty === d.v ? 'rgba(212,168,75,0.08)' : 'transparent',
                border: 'none', borderBottom: d.v < 2 ? `1px solid ${BR}` : 'none',
                cursor: 'pointer', textAlign: 'left', transition: 'background 0.15s', fontFamily: FF,
              }}>
                <div>
                  <div style={{ fontSize: 12.5, fontWeight: difficulty === d.v ? 500 : 400, color: difficulty === d.v ? A : C2 }}>{d.label}</div>
                  <div style={{ fontSize: 10.5, color: C3, marginTop: 1 }}>{d.sub}</div>
                </div>
                <div style={{ width: 6, height: 6, borderRadius: '50%', background: difficulty === d.v ? A : S3, border: `1px solid ${difficulty === d.v ? A : BRS}`, flexShrink: 0 }} />
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* CTA */}
      <div style={{ width: '100%', maxWidth: 760, marginTop: 18, display: 'flex', justifyContent: 'flex-end' }}>
        <motion.button whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }} onClick={onGenerate} style={{
          display: 'flex', alignItems: 'center', gap: 8, padding: '11px 24px',
          background: A, border: 'none', borderRadius: 5, color: '#18181a',
          fontSize: 13.5, fontWeight: 600, cursor: 'pointer', fontFamily: FF,
        }}>
          Generate Lesson <ArrowRight size={14} strokeWidth={2.5} />
        </motion.button>
      </div>

      {/* Recent lessons shelf */}
      <div style={{ width: '100%', marginTop: 60 }}>
        <div style={{ paddingInline: 'max(28px, calc(50% - 380px))', display: 'flex', alignItems: 'baseline', gap: 10, marginBottom: 14 }}>
          <h2 style={{ margin: 0, fontFamily: "'IBM Plex Serif', Georgia, serif", fontSize: 15.5, fontWeight: 600, color: C1 }}>Recent Lessons</h2>
          <span style={{ fontSize: 12, color: C3 }}>{LESSONS.length} sessions</span>
        </div>
        <div style={{ display: 'flex', gap: 14, overflowX: 'auto', paddingInline: 'max(28px, calc(50% - 380px))', paddingBottom: 10, scrollbarWidth: 'none' }}>
          {LESSONS.map(l => (
            <motion.div key={l.id} whileHover={{ y: -3 }} transition={{ duration: 0.15 }} onClick={onOpenLesson} style={{
              minWidth: 195, maxWidth: 195, background: S1, border: `1px solid ${BR}`, borderRadius: 6, overflow: 'hidden', cursor: 'pointer', flexShrink: 0,
            }}>
              <Thumbnail shape={l.shape} progress={l.progress} />
              <div style={{ padding: '10px 12px 12px' }}>
                <div style={{ fontSize: 12.5, fontWeight: 500, color: C1, marginBottom: 3, lineHeight: 1.3 }}>{l.title}</div>
                <div style={{ fontSize: 11, color: C3, marginBottom: 8, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{l.source}</div>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <span style={{ fontSize: 10.5, padding: '2px 7px', borderRadius: 3, background: `${l.subjectColor}22`, color: l.subjectColor }}>{l.subject}</span>
                  <span style={{ fontSize: 10.5, color: C3, display: 'flex', alignItems: 'center', gap: 3 }}>
                    <Clock size={10} />{l.duration}
                  </span>
                </div>
              </div>
            </motion.div>
          ))}
          <motion.div whileHover={{ y: -3 }} transition={{ duration: 0.15 }} style={{ minWidth: 90, border: `1px dashed ${BR}`, borderRadius: 6, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 8, cursor: 'pointer', flexShrink: 0, color: C3, fontSize: 12 }}>
            <ChevronRight size={16} /><span>View all</span>
          </motion.div>
        </div>
      </div>
    </div>
  )
}
