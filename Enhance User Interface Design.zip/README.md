
  # Enhance User Interface Design

  This is a code bundle for Enhance User Interface Design. The original project is available at https://www.figma.com/design/LqWKv7TubYyeZiwnVAJOZ3/Enhance-User-Interface-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  